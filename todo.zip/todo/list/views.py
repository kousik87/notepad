from turtle import title
from django.shortcuts import render,redirect
from django.http import HttpResponse 
from multiprocessing import context
from .models import Text

def todo(request):
    if request.method == 'POST':
        tit = request.POST['title'] 
        input = request.POST['task']
        Text.objects.create(title = tit , task=input)
        return redirect('todo')
    obj = Text.objects.all()
    context = {'texts': obj}
    return render(request, 'index.html', context)
def delete_task(request,pk):
    obj=Text.objects.get(id=pk)
    obj.delete()
    return redirect ('todo')

def update_task(request, pk):
    obj = Text.objects.get(id=pk)
    previous_task = obj.task
    if request.method == "POST":
        new_task = request.POST['task']
        obj.task = new_task
        obj.save()
        return redirect('todo')
    obj = Text.objects.all()
    context = {'tasks': obj, 'task' : previous_task}
    return render(request, 'index.html', context)    
   

   

        
